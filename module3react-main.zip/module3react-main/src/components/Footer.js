import React from 'react'
import { Card, CardBody } from 'reactstrap'
function Footer() {
    return (
        <div>
            <Card className="my-2 text-center ">
                <CardBody>
                 <h5 className="my-4"> All Rights are Reserved by @Module3 2020</h5>
                </CardBody>
            </Card>
        </div>
    )
}

export default Footer

